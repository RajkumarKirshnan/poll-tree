import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MainContainerComponent } from '@core/components/main-container/main-container.component';
import { AuthGuard } from './core/auth/services';
import { RouterPathConstants } from '@core/constants';

const routes: Routes = [
  { path: RouterPathConstants.HOME, component: MainContainerComponent , children: [
    
      /* user module routing  */
      { 
        path: RouterPathConstants.USER, 
        loadChildren: () => import(`./features/user/user.module`).then(m => m.UserModule),
        canActivate: [AuthGuard]
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
