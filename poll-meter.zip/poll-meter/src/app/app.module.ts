import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { StoreDevtoolsModule } from '@ngrx/store-devtools';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import {HttpClientModule} from '@angular/common/http';

import { CoreModule } from './core.module';
import { AppComponent } from './app.component';
import { environment } from '@app/env';
import { StoreModule } from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
//import { IdleTimeoutEffect } from '@core/store/effects/idleTimeout.effects';
//import { RouterEffects } from '@core/store/effects/router.effects';
import { ROOT_REDUCERS } from '@core/store';

import { httpInterceptorProviders } from './core/interceptors';

@NgModule({
  declarations: [
    AppComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CommonModule,
    RouterModule,
    StoreModule.forRoot(ROOT_REDUCERS),
    EffectsModule.forRoot([]),
    !environment.production ? StoreDevtoolsModule.instrument({ maxAge: 50, logOnly: false }) : [],    
    CoreModule    
  ],
  providers: [httpInterceptorProviders],
  bootstrap: [AppComponent]
})
export class AppModule { }

