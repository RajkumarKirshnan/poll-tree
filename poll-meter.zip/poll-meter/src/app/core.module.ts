import { NgModule } from '@angular/core';

import { MaterialModule } from '@shared/components/material/material.module';
import { CoreComponentModule } from '@core/components/core-component.module';
import { CustomComponentModule } from '@shared/components/custom/custom-component.module';
import { AppRoutingModule } from './app-routing.module';
import { AuthModule } from './core/auth/auth.module';

import { MainContainerComponent } from '@core/components/main-container/main-container.component';

@NgModule({
  declarations: [
    MainContainerComponent
  ],
  imports: [
    MaterialModule,    
    CoreComponentModule,
    CustomComponentModule,
    AppRoutingModule,
    AuthModule
  ]
})
export class CoreModule { }
