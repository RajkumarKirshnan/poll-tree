import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginPageComponent } from './containers/login-page/login-page.component';
import { ResetPasswordPageComponent } from './containers/reset-password-page/reset-password-page.component';
import { ForgotPasswordPageComponent } from './containers/forgot-password-page/forgot-password-page.component';
import { RouterPathConstants } from '@core/constants';

const routes: Routes = [
  {
    path: '',
    redirectTo: `/${RouterPathConstants.LOGIN}`,
    pathMatch: 'full'
  },

  /* login module routing */
  { path: RouterPathConstants.LOGIN, component: LoginPageComponent },
  { path: RouterPathConstants.RESET_PASSWORD, component: ResetPasswordPageComponent },
  { path: RouterPathConstants.FORGOT_PASSWORD, component: ForgotPasswordPageComponent }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],  
  exports: [RouterModule],
})
export class AuthRoutingModule {
    constructor(){ }
}