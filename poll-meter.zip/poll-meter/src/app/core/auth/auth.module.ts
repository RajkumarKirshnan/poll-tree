import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule } from '@angular/forms';
import { StoreModule } from '@ngrx/store';
import { EffectsModule } from '@ngrx/effects';

import { AuthEffects } from './store/effects';
import * as fromAuth from './store/reducers';

import { MaterialModule } from '@shared/components/material/material.module';
import { CustomComponentModule } from '@shared/components/custom/custom-component.module';
import { AuthRoutingModule } from './auth-routing.module';
import { LoginPageComponent } from './containers/login-page/login-page.component';
import { ForgotPasswordPageComponent } from './containers/forgot-password-page/forgot-password-page.component';
import { ResetPasswordPageComponent } from './containers/reset-password-page/reset-password-page.component';

const authComponents: any[] = [LoginPageComponent, ForgotPasswordPageComponent, ResetPasswordPageComponent];

@NgModule({
  declarations: authComponents,
    imports: [
      CommonModule,
      ReactiveFormsModule,
      MaterialModule,
      AuthRoutingModule,
      CustomComponentModule,
      StoreModule.forFeature(fromAuth.authFeatureKey, fromAuth.reducers),
      EffectsModule.forFeature([AuthEffects])
    ],
    exports: authComponents    
    // entryComponents: [LogoutConfirmationDialogComponent],
  })
  export class AuthModule {}