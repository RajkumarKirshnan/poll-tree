import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { RouterPathConstants } from '@core/constants';

@Component({
  selector: 'pm-forgot-password-page',
  templateUrl: './forgot-password-page.component.html',
  styleUrls: ['./forgot-password-page.component.scss']
})
export class ForgotPasswordPageComponent implements OnInit {

  constructor(private myRoute: Router) { }

  ngOnInit(): void {
  }

  submit(formVal) {
    if (formVal.email === "admin@gmail.com") {
        this.myRoute.navigate([RouterPathConstants.LOGIN]);
    } else {
      this.myRoute.navigate([RouterPathConstants.FORGOT_PASSWORD]);
    }
  }

}
