import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

import { ILoginUserCredential } from '../../models/index';
import {AuthStoreFacade} from '../../store/facades';
import { RouterPathConstants } from '@core/constants';

@Component({
  selector: 'pm-login-page',
  templateUrl: './login-page.component.html',
  styleUrls: ['./login-page.component.scss']
})
export class LoginPageComponent implements OnInit {

  constructor(private authStoreFacade: AuthStoreFacade, private router: Router) {

  }

  ngOnInit(): void {
    
  }

  submit(credential: ILoginUserCredential) {
    this.authStoreFacade.login(credential);
    //this.router.navigate([RouterPathConstants.HOME_USER_LIST_USERS]);
  }

}
