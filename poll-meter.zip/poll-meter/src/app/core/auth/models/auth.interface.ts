export interface ILoginUserCredential{
    username: string;
    password: string;
    confirmPassword?: string;
}

export interface IOAuthTokenResponse{
    access_token: string;
    token_type: string;
    refresh_token: string;
    expires_in: number;
    scope: string;
}

export interface IOAuthToken{
    authToken: IOAuthTokenResponse;
}
