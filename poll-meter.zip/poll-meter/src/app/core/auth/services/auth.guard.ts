import { Injectable } from '@angular/core';
import { CanActivate } from '@angular/router';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';
import { Store, select } from '@ngrx/store';
import { State, selectLoggedIn } from '../store/reducers';
import { AuthStoreFacade } from '../store/facades';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private store: Store<State>, private facade: AuthStoreFacade){}
  canActivate(): Observable<boolean> {
    return this.store.pipe(
      select(selectLoggedIn),
      map(authed => {
        if(!authed){
          this.facade.loginRedirect();
          return false;
        }
        return true;
      })
    )    
  }  
}
