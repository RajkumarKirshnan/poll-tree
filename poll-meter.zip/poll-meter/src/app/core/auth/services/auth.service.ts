import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@app/env';
import { Observable } from 'rxjs';
import { ILoginUserCredential, IOAuthTokenResponse } from '../models';
import { AuthApiConstants } from '../store/constants/auth.api.constants';
import { AuthStoreFacade } from '../store/facades';
import { of } from 'rxjs';
@Injectable({
    providedIn: 'root'
})

export class AuthService{
    constructor( private http: HttpClient, private facade: AuthStoreFacade){
    }

    public login(userCrediential: ILoginUserCredential): Observable<IOAuthTokenResponse> {
        let formData: FormData = new FormData();
        formData.append('grant_type', 'password');
        formData.append('username', userCrediential.username);
        formData.append('password', userCrediential.password);
        let IOAuth:IOAuthTokenResponse = { access_token: "access_token",
        token_type: 'token_type',
        refresh_token: 'refresh_token',
        expires_in: 132,
        scope: 'scope'
        }
        return of(IOAuth);//this.http.post<IOAuthTokenResponse>(AuthApiConstants.OAUTH_TOKEN_URL, formData);
    }

    public refreshToken(): Observable<IOAuthTokenResponse> {
        let refreshToken:string = this.facade.getToken().refresh_token,
        formData: FormData = new FormData();
        formData.append('grant_type', 'refresh_token');
        formData.append('refresh_token', refreshToken);

        return this.http.post<IOAuthTokenResponse>(AuthApiConstants.OAUTH_TOKEN_URL, formData);     
    }

    public logout(): Observable<any> {
        return this.http.delete<any>(AuthApiConstants.OAUTH_TOKEN_URL);
    }

}
