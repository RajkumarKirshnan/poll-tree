import { createAction, props } from '@ngrx/store';
import { LoginConstants } from '../constants';
import { ILoginUserCredential, IOAuthTokenResponse } from '../../models';

export const login = createAction(
    LoginConstants.LOGIN,
    props<{ credential: ILoginUserCredential }>()
);

export const loginSuccess = createAction(
    LoginConstants.LOGIN_SUCCESS,
    props<{ authToken: IOAuthTokenResponse }>()
);

export const loginFailure = createAction(
    LoginConstants.LOGIN_FAILURE,
    props<{ error: any }>()
);

export const loginRedirect = createAction(
    LoginConstants.LOGIN_REDIRECT
);

export const refreshToken = createAction(
    LoginConstants.REFRESH_TOKEN
);

export const refreshTokenSuccess = createAction(
    LoginConstants.REFRESH_TOKEN_SUCCESS,
    props<{ authToken: IOAuthTokenResponse }>()
);

export const refreshTokenFailure = createAction(
    LoginConstants.REFRESH_TOKEN_FAILURE,
    props<{ error: any }>()
);

export const logout = createAction(
    LoginConstants.LOGOUT
);

export const logoutSuccess = createAction(
    LoginConstants.LOGOUT_SUCCESS
);

export const logoutFailure = createAction(
    LoginConstants.LOGOUT_FAILURE,
    props<{ error: any }>()
);

export const logoutConfirmation = createAction(
    LoginConstants.LOGOUT_CONFIRMATION
);

export const logoutConfirmationDismiss = createAction(
    LoginConstants.LOGOUT_CONFIRMATION_DISMISS
);