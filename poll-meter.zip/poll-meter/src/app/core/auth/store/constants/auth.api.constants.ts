import {environment} from '@app/env';

export class AuthApiConstants {
    private static BASE_URL: string = environment.oauthApi.baseUrl;
    public static OAUTH_TOKEN_URL: string = AuthApiConstants.BASE_URL+"/oauth/token";
}