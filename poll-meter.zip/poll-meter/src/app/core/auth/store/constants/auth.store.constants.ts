export class LoginConstants{
    public static LOGIN: string = '[Auth] Login';
    public static LOGIN_SUCCESS: string = '[Auth/API] Login Success';
    public static LOGIN_FAILURE: string = '[Auth/API] Login Failure';
    public static LOGIN_REDIRECT: string = '[Auth/API] Login Redirect';

    public static REFRESH_TOKEN: string = '[Auth] Refresh Token';
    public static REFRESH_TOKEN_SUCCESS: string = '[Auth/API] Refresh Token Success';
    public static REFRESH_TOKEN_FAILURE: string = '[Auth/API] Refresh Token Failure';

    public static LOGOUT: string = '[Auth] Logout';
    public static LOGOUT_SUCCESS: string = '[Auth/API] Logout Success';
    public static LOGOUT_FAILURE: string = '[Auth/API] Logout Failure';

    public static LOGOUT_CONFIRMATION: string = '[Auth] Logout Confirmation';
    public static LOGOUT_CONFIRMATION_DISMISS: string = '[Auth] Logout Confirmation Dismiss';
}