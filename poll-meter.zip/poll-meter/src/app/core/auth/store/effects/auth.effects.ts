import { Injectable } from '@angular/core';
import { Actions, createEffect, ofType } from '@ngrx/effects';
import { Router } from '@angular/router';
import { of } from 'rxjs';
import { catchError, exhaustMap, map, tap } from 'rxjs/operators';

import * as AuthActions from '../actions';
import { AuthService } from '../../services';
import { IOAuthToken, IOAuthTokenResponse } from '../../models';
import { RouterPathConstants } from '@core/constants';

@Injectable({
    providedIn: 'root'
})

export class AuthEffects {
    constructor(private actions: Actions, private authService: AuthService, private router: Router){}

    login$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.login),
        map(action => action.credential),
        exhaustMap((crediential) => this.authService.login(crediential).pipe(
            map((tokenResponse: IOAuthTokenResponse) => {
                let iOAuthToken: IOAuthToken = { authToken: tokenResponse }
                return AuthActions.loginSuccess(iOAuthToken);
            }),
            catchError(err => of(AuthActions.loginFailure(err)))
        ))
    ));

    loginSuccess$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.loginSuccess),
        tap(() => {
            this.router.navigate([RouterPathConstants.HOME_USER_LIST_USERS]);
        })
    ),{dispatch: false});

    loginFailure$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.loginFailure),
        tap(() => {
            this.router.navigate([RouterPathConstants.LOGIN]);
        })
    ),{dispatch :false})

    loginRedirect$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.loginRedirect),
        tap(() => this.router.navigate([RouterPathConstants.LOGIN]))
    ), {dispatch: false});

    refreshToken$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.refreshToken),
        exhaustMap(() => this.authService.refreshToken().pipe(
            map((tokenResponse: IOAuthTokenResponse) => {
                let iOAuthToken: IOAuthToken = { authToken: tokenResponse }
                return AuthActions.refreshTokenSuccess(iOAuthToken);
            }),
            catchError(err => of(AuthActions.refreshTokenFailure(err)))
        ))
    ));

    refreshTokenSuccess$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.refreshTokenSuccess),
        tap(() => {
            this.router.navigate([RouterPathConstants.HOME_USER_LIST_USERS]);
        })
    ),{dispatch: false});

    refreshTokenFailure$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.refreshTokenFailure),
        tap(() => {
            //this.router.navigate([RouterPathConstants.LOGIN]);
        })
    ),{dispatch :false})
    
    logout$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.logout),
        exhaustMap(() => this.authService.logout().pipe(
            map(() => AuthActions.logoutSuccess()),
            catchError(err => of(AuthActions.logoutFailure(err)))
        ))    
    ));

    logoutSuccess$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.logoutSuccess),
        tap(() => {
            this.router.navigate([RouterPathConstants.LOGIN]);
        })
    ),{dispatch: false});

    logoutFailure$ = createEffect(() => this.actions.pipe(
        ofType(AuthActions.logoutFailure),
        tap(() => {
            //alert("logoutFailure");
        })
    ),{dispatch :false})
}