import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Subscription } from 'rxjs';

import * as AuthActions from '../actions';
import { ILoginUserCredential, IOAuthTokenResponse } from '../../models';
import { State, selectToken } from '../reducers';

@Injectable({
    providedIn: "root"
})

export class AuthStoreFacade {

    constructor(private store: Store<State>) { }

    public login(credential:ILoginUserCredential): void{
        this.store.dispatch(AuthActions.login({ credential }));
    }

    public refreshToken(): void{
        this.store.dispatch(AuthActions.refreshToken());
    }

    public logout(): void{
        this.store.dispatch(AuthActions.logout());
    }

    public loginRedirect(): void{
        this.store.dispatch(AuthActions.loginRedirect());
    }

    public getToken(): IOAuthTokenResponse {
       let responseToken:IOAuthTokenResponse; 
       const tokenSubscription: Subscription = this.store.pipe(select(selectToken))
        .subscribe( tokenResponse=> {
            responseToken = tokenResponse;            
        });
        tokenSubscription.unsubscribe();
        return responseToken;
    }

}