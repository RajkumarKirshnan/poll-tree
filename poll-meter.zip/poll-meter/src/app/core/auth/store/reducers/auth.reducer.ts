import { createReducer, on } from '@ngrx/store';
import { IOAuthTokenResponse } from '../../models';
import { loginSuccess, logoutSuccess, refreshTokenSuccess } from '../actions';

export const authStatusKey = 'authStatus';

export interface State{
    authToken: IOAuthTokenResponse | null;
}

export const initialState: State = {
    authToken: null
}

export const reducer = createReducer(
    initialState,
    on(loginSuccess, (state, {authToken}) => ({...state, authToken})),
    on(refreshTokenSuccess, (state, {authToken}) => ({...state, authToken})),
    on(logoutSuccess, () => initialState)
)

export const getToken = (state: State) => state.authToken;