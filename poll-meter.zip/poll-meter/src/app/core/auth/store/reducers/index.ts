import { combineReducers, Action, createFeatureSelector, createSelector } from '@ngrx/store';
import * as fromRoot from '@core/store/reducers/ui-reducer';
import * as fromAuth from './auth.reducer';

export const authFeatureKey = 'auth';

export interface AuthState{
    [fromAuth.authStatusKey] : fromAuth.State;
};

export interface State extends fromRoot.State{
    [authFeatureKey]: AuthState
};

export function reducers(state: AuthState | undefined, action: Action){
    return combineReducers({
        [fromAuth.authStatusKey]: fromAuth.reducer
    })(state, action)
};

export const selectAuthState = createFeatureSelector<State, AuthState>(
    authFeatureKey
);

export const selectAuthStatusState = createSelector(
    selectAuthState,
    state => state[fromAuth.authStatusKey]
);

export const selectToken = createSelector(
    selectAuthStatusState,
    fromAuth.getToken
);

export const selectLoggedIn = createSelector(selectToken, authToken => !!authToken);