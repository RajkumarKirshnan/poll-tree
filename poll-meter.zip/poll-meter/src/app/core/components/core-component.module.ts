import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';

import { MaterialModule } from '@shared/components/material/material.module';

import { HeaderComponent } from './header/header.component';
import { LeftNavComponent } from './left-nav/left-nav.component';
import { FooterComponent } from './footer/footer.component';
import { ContentComponent } from './content/content.component';

const coreComponents: any[] = [HeaderComponent, LeftNavComponent, FooterComponent, ContentComponent]

@NgModule({
  declarations: coreComponents,
  imports: [
    CommonModule,
    MaterialModule,
    RouterModule
  ],
  exports:coreComponents
})
export class CoreComponentModule { }
