import { Component, OnInit } from "@angular/core";
import { Router } from "@angular/router";

import {AuthStoreFacade} from '@core/auth/store/facades';
import{ RouterPathConstants } from '@core/constants';

@Component({
  selector: "pm-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.scss"]
})
export class HeaderComponent implements OnInit {

  submenu = false;
  userSubmenu=false;
  fullscreen$;

  public userAddUserUrl:string='';
  public userListUsersUrl:string='';

  constructor(private router: Router, private authStoreFacade: AuthStoreFacade) {
    this.userAddUserUrl = RouterPathConstants.USER_ADD_USER;
    this.userListUsersUrl = RouterPathConstants.USER_LIST_USERS;
  }

  ngOnInit() {

  }

  logout() {
    this.authStoreFacade.logout();
  }

  submenuOpen(type) {
    if (type === "submenu") {
      this.submenu = !this.submenu;
    }
    if (type === "userSubmenu") {
      this.userSubmenu=!this.userSubmenu;
    }

  }

}
