import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'pm-left-nav',
  templateUrl: './left-nav.component.html',
  styleUrls: ['./left-nav.component.scss']
})
export class LeftNavComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
