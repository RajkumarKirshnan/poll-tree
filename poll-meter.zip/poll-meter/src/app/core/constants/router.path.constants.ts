export class RouterPathConstants{

    public static LOGIN:string = "login";
    public static RESET_PASSWORD:string = "reset-password";
    public static FORGOT_PASSWORD:string = "forgot-password";

    public static HOME:string = "home";
    public static USER:string = "user";
    public static LIST_USERS:string = "list-users"
    public static ADD_USER:string = "add-user";
    
    public static USER_ADD_USER:string = "user/add-user";
    public static USER_LIST_USERS:string = "user/list-users";
    
    public static HOME_USER_LIST_USERS:string = "home/user/list-users";      

}