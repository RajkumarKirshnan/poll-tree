import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

import { AuthStoreFacade } from '@core/auth/store/facades';

@Injectable()
export class AuthInterceptor implements HttpInterceptor {

  constructor(private facade: AuthStoreFacade) {}

  intercept(request: HttpRequest<unknown>, next: HttpHandler): Observable<HttpEvent<unknown>> {    
    let username:string = 'mobile',
        password:string = 'pin',
        authorizationData: string = '',
        accessToken:string = '',
        authReq;

    if(request.url.match('token')){
      authorizationData = 'Basic ' + btoa(username + ':' + password);
    } else {      
      accessToken = this.facade.getToken().access_token;
      authorizationData = 'Bearer ' + accessToken;  
    } 

    if (request.url.match('token') && request.method === 'DELETE') {
      accessToken = this.facade.getToken().access_token;
      authReq = request.clone({
      headers: request.headers.set('Authorization', authorizationData)
      .set('access_token', 'Bearer ' + accessToken)
      });
    } else {
      authReq = request.clone({
        headers: request.headers.set('Authorization', authorizationData)
      });
    }

    // send cloned request with header to the next handler.
    return next.handle(authReq);
  }
}
