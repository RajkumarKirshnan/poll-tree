import { Component, OnInit } from '@angular/core';
import { AuthService } from '@core/auth/services';
import { AuthStoreFacade } from '@core/auth/store/facades';

@Component({
  selector: 'pm-add-user-page',
  templateUrl: './add-user-page.component.html',
  styleUrls: ['./add-user-page.component.scss']
})
export class AddUserPageComponent implements OnInit {

  constructor(private authService: AuthService, private facade: AuthStoreFacade) { }

  ngOnInit(): void {
    /*this.authService.getLoggedInUserProfileDetails({}).subscribe((data)=>{
      console.log('getLoggedInUserProfileDetails : ',data);
      this.facade.refreshToken();
    });*/
  }

  submit(formVal) {
    alert("user value saved");
  }

}
