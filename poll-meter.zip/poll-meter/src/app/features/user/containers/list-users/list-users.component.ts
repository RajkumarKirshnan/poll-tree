import { Component, OnInit, ViewChild, ChangeDetectorRef } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { of, Observable } from 'rxjs';
import { MatDialog, MAT_DIALOG_DATA, MatDialogRef, MatDialogConfig } from '@angular/material/dialog';
import { AddUserComponent } from '@shared/components/custom/add-user/add-user.component';
import { IUserForm } from '../../models';
import { ButtonRendererComponent } from '@shared/components/custom/renderer/button-renderer.component';
@Component({
  selector: 'pm-list-users',
  templateUrl: './list-users.component.html',
  styleUrls: ['./list-users.component.scss']
})
export class ListUsersComponent implements OnInit {
  @ViewChild('agGrid') agGrid: AgGridAngular;

  frameworkComponents: any;

  public columnDefs = [
    {headerName: 'First Name', field: 'basicInfo.firstName', sortable: true, filter: true },,
    {headerName: 'Last Name', field: 'basicInfo.lastName', sortable: true, filter: true },
    {headerName: 'Email', field: 'basicInfo.email', sortable: true, filter: true },
    {headerName: 'ContactNo', field: 'basicInfo.contactNo', sortable: true, filter: true },
    {headerName: 'User Type', field: 'basicInfo.userTypeId', sortable: true, filter: true },
    {headerName: 'Status', field: 'status', sortable: true, filter: true },
    // {headerName: 'State', field: 'state', sortable: true, filter: true },
    {headerName: 'Privilage', field: 'privilage', sortable: true, filter: true },
    {headerName: 'Action', cellRenderer: 'buttonRenderer',
    cellRendererParams: {
      visibility: this.doFormVisible.bind(this),
      edit:  this.doFormEdit.bind(this),
      label: 'Click 1'
    }
  }
];

constructor(private dialog: MatDialog, private cdr: ChangeDetectorRef) {
  this.frameworkComponents = {
    buttonRenderer: ButtonRendererComponent,
  }
}


public rowData: Array<object> = [
    // { firstName: 'User1', lastName:'test', email: 'user1@gmail.com', gender:"Male", contactNo:'1112223333',userType: 'Administrator', status: 'Active', privilage: 'Home', action:'view'},
    // { firstName: 'User2', lastName:'test', email: 'user2@gmail.com', gender:"Male", contactNo:'1113334444', userType: 'Non-Administrator', status: 'In-Active', privilage: 'Dashboard', action:'\f06e'},
];

autoGroupColumnDef = {
  headerName: 'Model',
  field: 'model',
  cellRenderer: 'agGroupCellRenderer',
  cellRendererParams: {
      checkbox: true
  }
};
  

  ngOnInit(): void {
  }

  public createUser(): void{
    const dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = {title:"Create User", formData:{}};
    dialogConfig.width = "800px";
    dialogConfig.height = "500px";
    const matDialogRef: MatDialogRef<AddUserComponent> = this.dialog.open(AddUserComponent, dialogConfig);
    matDialogRef.afterClosed().subscribe((userForm: IUserForm)=>{      
        let createUser: IUserForm = {
          basicInfo: userForm.basicInfo,
          subscriptionInfo: userForm.subscriptionInfo,
          geography:userForm.geography,
          modules: userForm.modules,
          logo: userForm.logo
        };
      
      this.rowData = [...this.rowData, createUser];
      this.cdr.detectChanges();      
    })
  }

  private doFormVisible(evt): void{ 
    const dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = {title:"View User", formData:evt.rowData};    
    dialogConfig.width = "800px";
    dialogConfig.height = "500px";
    const matDialogRef: MatDialogRef<AddUserComponent> = this.dialog.open(AddUserComponent, dialogConfig);
    matDialogRef.afterClosed().subscribe((data: string)=>{
      console.log(data);
    })
  }

  private doFormEdit(evt): void{
    const dialogConfig: MatDialogConfig = new MatDialogConfig();
    dialogConfig.data = {title:"Edit User", formData:evt.rowData};
    dialogConfig.width = "800px";
    dialogConfig.height = "500px";
    const matDialogRef: MatDialogRef<AddUserComponent> = this.dialog.open(AddUserComponent, dialogConfig);
    matDialogRef.afterClosed().subscribe((data: string)=>{
      console.log(data);
    });
  }

  public getSelectedRows() {    
    
    const selectedNodes = this.agGrid.api.getSelectedNodes();
    const selectedData = selectedNodes.map( node => node.data );
    const selectedDataStringPresentation = selectedData.map( node => node.make + ' ' + node.model).join(', ');
    console.log(`Selected nodes: ${selectedDataStringPresentation}`);
}

}
