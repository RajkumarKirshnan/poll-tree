export interface ILoggedInUserProfileDetails {
    userId: number;
    managerId: number;
    managerPersonalInfo: ManagerPersonalInfo;
    personalInfo: PersonalInfo;
    userSubcription: UserSubcription;
    role: Role;
  }
  
  interface Role {
    roleId: number;
    roleName: string;
    permittedActivities?: any;
  }
  
  interface UserSubcription {
    subsStartDate: string;
    subsEndDate: string;
    stateCode: string;
    partyId: number;
    partyUserSubs?: any;
  }
  
  interface PersonalInfo {
    firstName: string;
    lastName: string;
    middleName: string;
    email: string;
    contactNo: string;
  }
  
  interface ManagerPersonalInfo {
    firstName: string;
    lastName: string;
    middleName: string;
    email?: any;
    contactNo?: any;
  }