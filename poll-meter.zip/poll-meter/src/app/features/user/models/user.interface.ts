export interface IUser {
    managerId: number;
    userId: number;
    password: string;
    personalInfo: PersonalInfo;
    userSubcription: UserSubcription;
    role: Role;
  }
  
  interface Role {
    roleId: number;
  }
  
  interface UserSubcription {
    subsStartDate: string;
    subsEndDate: string;
    stateCode: string;
  }
  
  interface PersonalInfo {
    firstName: string;
    lastName: string;
    middleName: string;
    email: string;
    contactNo: string;
  }