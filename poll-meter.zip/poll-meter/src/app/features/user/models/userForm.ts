export interface IUserFormManagerId{
    managerId: number;
    userForm: IUserForm[];
}
export interface IUserForm {  
  basicInfo: BasicInfo;
  subscriptionInfo: SubscriptionInfo;
  geography: Geography;
  modules: Module[];
  logo: Logo;
}

interface Logo {
  imageType: string;
  imageValue: string;
}

interface Module {
  moduleId: number;
  isActive: boolean;
}

interface Geography {
  states: State[];
}

interface State {
  stateCode: string;
  isDefault: boolean;
}

interface SubscriptionInfo {
  subsStartDate: string;
  subsEndDate: string;
}

interface BasicInfo {
  firstName: string;
  lastName: string;
  middleName: string;
  gender: string;
  email: string;
  contactNo: string;
  isActive: boolean;
  userTypeId: number;
  address: Address;
}

interface Address {
  stateCode: string;
  pinCode: string;
  addressLine1: string;
  addressLine2: string;
}