import { createAction, props } from '@ngrx/store';

import { IUser } from '../../models';
import { UserAPIConstants } from '../constants';

export const loadAllUsersSuccess = createAction(
    UserAPIConstants.LOAD_ALL_USERS_SUCCESS,
    props<{ users: IUser[] }>()
);

export const loadAllUsersFailure = createAction(
    UserAPIConstants.LOAD_ALL_USERS_FAILURE,
    props<{ error: any }>()
);

export const loadUserSuccess = createAction(
    UserAPIConstants.LOAD_USER_SUCCESS,
    props<{ user: IUser }>()
);

export const loadUserFailure = createAction(
    UserAPIConstants.LOAD_USER_FAILURE,
    props<{ error: any }>()
);

export const createUserSuccess = createAction(
    UserAPIConstants.CREATE_USER_SUCCESS,
    props<{ user: IUser }>()
);

export const createUserFailure = createAction(
    UserAPIConstants.CREATE_USER_FAILURE,
    props<{ error: any }>()
);

export const searchUsersSuccess = createAction(
    UserAPIConstants.SEARCH_USERS_SUCCESS,
    props<{ searchUsers: IUser[] }>()
);

export const searchUsersFailure = createAction(
    UserAPIConstants.SEARCH_USERS_FAILURE,
    props<{ error: any }>()
);

export const updateUserSuccess = createAction(
    UserAPIConstants.UPDATE_USER_SUCCESS,
    props<{ user: IUser }>()
);

export const updateUserFailure = createAction(
    UserAPIConstants.UPDATE_USER_FAILURE,
    props<{ error: any }>()
);

export const deleteUserSuccess = createAction(
    UserAPIConstants.DELETE_USER_SUCCESS,
    props<{ deletedUserId: string }>()
);

export const deleteUserFailure = createAction(
    UserAPIConstants.DELETE_USER_FAILURE,
    props<{ error: any }>()
);