import { createAction, props } from '@ngrx/store';

import { IUser } from '../../models';
import { UserConstants } from '../constants';

export const loadAllUsers = createAction(
    UserConstants.LOAD_ALL_USERS
);

export const loadUser = createAction(
    UserConstants.LOAD_USER,
    props<{userId: string}>()
);

export const createUser = createAction(
    UserConstants.CREATE_USER,
    props<{user: IUser}>()
);

export const updateUser = createAction(
    UserConstants.UPDATE_USER,
    props<{user: IUser}>()
);

export const searchUser = createAction(
    UserConstants.SEARCH_USERS,
    props<{searchId: string}>()
)

export const deleteUser = createAction(
    UserConstants.DELETE_USER,
    props<{userId: string}>()
);