export class UserConstants{
    
    public static LOAD_ALL_USERS: string = '[Add User] Load All Users';
    public static LOAD_USER: string = '[Add User] Load User';
    public static CREATE_USER: string = '[Add User] Create User';
    public static UPDATE_USER: string = '[Add User] Update User';
    public static SEARCH_USERS: string = '[Add User] Search Users';
    public static DELETE_USER: string = '[Add User] Delete User';
    
}