export class UserAPIConstants{
    public static LOAD_ALL_USERS_SUCCESS: string = '[User/API] Load All Success';
    public static LOAD_ALL_USERS_FAILURE: string = '[User/API] Load All Failure';
    
    public static LOAD_USER_SUCCESS: string = '[User/API] Load Success';
    public static LOAD_USER_FAILURE: string = '[User/API] Load Failure';

    public static CREATE_USER_SUCCESS: string = '[User/API] Create Success';
    public static CREATE_USER_FAILURE: string = '[User/API] Create Failure';    

    public static UPDATE_USER_SUCCESS: string = '[User/API] Update Success';
    public static UPDATE_USER_FAILURE: string = '[User/API] Update Failure';    

    public static SEARCH_USERS_SUCCESS: string = '[User/API] Search Success';
    public static SEARCH_USERS_FAILURE: string = '[User/API] Search Failure';    

    public static DELETE_USER_SUCCESS: string = '[User/API] Delete Success';
    public static DELETE_USER_FAILURE: string = '[User/API] Delete Failure';    
}