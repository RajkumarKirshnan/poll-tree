import { Injectable } from '@angular/core';
import { createEffect, Actions, ofType } from '@ngrx/effects';
import { of } from 'rxjs';
import { tap } from 'rxjs/operators';
import { catchError, exhaustMap, map, startWith, switchMap, pluck } from 'rxjs/operators';

import * as UserActions from '../actions';
import { UserService } from '../services';
import { IUser } from '../../models';
import { UserAPIConstants } from '../constants';

@Injectable({
    providedIn: 'root'
})

export class UserEffects{
    constructor(private actions$:Actions, private userService: UserService){}

    loadAllUsers$ = createEffect( () => this.actions$.pipe(
        ofType(UserActions.loadAllUsers),
        startWith(UserActions.loadAllUsers()),
        switchMap(()=> this.userService.loadAllUsers().pipe(
            map((users: IUser[]) => UserActions.loadAllUsersSuccess({users})),
            catchError(err => {
                return of(UserActions.loadAllUsersFailure({error: {concern: UserAPIConstants.LOAD_ALL_USERS_FAILURE, error: err}}))
            })
        ))
    ));

    loadAllUsersSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.loadAllUsersSuccess),
        tap(() => {
            console.log('Loaded all users');
        })
    ),{dispatch: false});

    loginAllUsersFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.loadAllUsersFailure),
        tap(()=>{
            console.log('Load all users failed');
        })
    ),{dispatch: false});

    loadUser$ = createEffect( () => this.actions$.pipe(
        ofType(UserActions.loadUser),
        map((action)=>action.userId),
        startWith((userId: string)=>UserActions.loadUser({userId})),        
        switchMap((userId: string)=> this.userService.loadUser(userId).pipe(
            map((user: IUser) => UserActions.loadUserSuccess({user})),
            catchError(err => {
                return of(UserActions.loadUserFailure({error: {concern: UserAPIConstants.LOAD_ALL_USERS_FAILURE, error: err}}))
            })
        ))
    ));

    loadUserSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.loadUserSuccess),
        tap(() => {
            console.log('Loaded user success');
        })
    ),{dispatch: false});

    loginUserFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.loadUserFailure),
        tap(()=>{
            console.log('Load user failed');
        })
    ),{dispatch: false});

    createUser$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.createUser),
        map((action)=>action.user),
        switchMap((user) => this.userService.createUser(user).pipe(
            map((user: IUser) => UserActions.createUserSuccess({user})),
            catchError(err => {
                return of(UserActions.createUserFailure({error: {concern: UserAPIConstants.CREATE_USER_FAILURE, error: err}}))
            })
        ))
    ));

    createUserSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.createUserSuccess),
        tap(() => {
            console.log('Create user success');
        })
    ),{dispatch: false});

    createUserFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.createUserFailure),
        tap(()=>{
            console.log('Create user failed');
        })
    ),{dispatch: false});

    updateUser$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.updateUser),
        map(action => action.user),
        switchMap((user) => this.userService.updateUser(user).pipe(
            map((user: IUser) => UserActions.updateUserSuccess({user})),
            catchError(err => {
                return of(UserActions.updateUserFailure({error: {concern: UserAPIConstants.UPDATE_USER_FAILURE, error: err}}))
            })
        ))
    ));

    updateUserSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.updateUserSuccess),
        tap(() => {
            console.log('Update user success');
        })
    ),{dispatch: false});

    updateUserFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.updateUserFailure),
        tap(()=>{
            console.log('Update user failed');
        })
    ),{dispatch: false});

    searchUsers$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.searchUser),
        map(action => action.searchId),
        switchMap((searchId) => this.userService.searchUser(searchId).pipe(
            map((searchUsers: IUser[]) => UserActions.searchUsersSuccess({searchUsers})),
            catchError(err => {
                return of(UserActions.searchUsersFailure({error: {concern: UserAPIConstants.SEARCH_USERS_FAILURE, error: err}}))
            })
        ))
    ));

    searchUsersSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.searchUsersSuccess),
        tap(() => {
            console.log('search users success');
        })
    ),{dispatch: false});

    searchUsersFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.searchUsersFailure),
        tap(()=>{
            console.log('search users failed');
        })
    ),{dispatch: false});

    deleteUser$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.deleteUser),
        map(action => action.userId),
        switchMap((deleteUserId) => this.userService.deleteUser(deleteUserId).pipe(
            map((deletedUserId: string) => UserActions.deleteUserSuccess({deletedUserId})),
            catchError((err: Error) => {
                return of(UserActions.deleteUserFailure({error: {concern: UserAPIConstants.DELETE_USER_FAILURE, error: err}}))
            })
        ))
    ));

    deleteUserSuccess$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.deleteUserSuccess),
        tap(() => {
            console.log('Delete user success');
        })
    ),{dispatch: false});

    deleteUserFailure$ = createEffect(() => this.actions$.pipe(
        ofType(UserActions.deleteUserFailure),
        tap(()=>{
            console.log('Delete users failed');
        })
    ),{dispatch: false});
}