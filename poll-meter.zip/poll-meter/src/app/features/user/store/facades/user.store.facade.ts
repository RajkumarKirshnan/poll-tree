import { Injectable } from '@angular/core';
import { select, Store } from '@ngrx/store';
import { Observable } from 'rxjs';

import * as UserActions from '../actions';
import { IUser } from '../../models';
import { State, getAllUsers, getUserById } from '../reducers';

@Injectable({
    providedIn: "root"
})

export class UserStoreFacade {

    constructor(private store: Store<State>) { }

    public loadAllUser(): void{
        this.store.dispatch(UserActions.loadAllUsers());
    }

    public loadUser(userId: string): void{
        this.store.dispatch(UserActions.loadUser({userId}));
    }

    public updateUser(user: IUser): void {
        this.store.dispatch(UserActions.updateUser({user}));
    }

    public createUser(user: IUser): void {
        this.store.dispatch(UserActions.createUser({user}));
    }

    public searchUser(searchId: string): void {
        this.store.dispatch(UserActions.searchUser({searchId}));
    }
    
    public deleteUser(userId: string): void {
        this.store.dispatch(UserActions.deleteUser({userId}));
    }

    public getAllUsers(): Observable<IUser[]>{
        return this.store.pipe(select(getAllUsers));
    }

    public getUserById(userId: string): Observable<IUser> {
        return this.store.pipe(select(getUserById(userId)));
      }    
}