import { createReducer, on } from '@ngrx/store';
import { EntityState, createEntityAdapter } from '@ngrx/entity';

import * as UserActions from '../actions';
import { IUser } from '../../models';

export const userServiceKey = 'userServiceKey';

export const userAdapter = createEntityAdapter<IUser>({
    selectId: (user: IUser) => user.userId,
    sortComparer: false
});

export interface State extends EntityState<IUser>{
    users: IUser[],
    loading: boolean;
    loaded: boolean;
    ids: string[];
}

export const initialState: State = userAdapter.getInitialState({
    users: [],
    loading: false,
    loaded: false,
    ids: []
});

export const reducer = createReducer(
    initialState,
    on(UserActions.loadAllUsersSuccess, (state, {users}) => 
    userAdapter.addMany(users, state)),

    on(UserActions.createUserSuccess, (state, {user}) => 
    userAdapter.addOne(user, state)),

    on(UserActions.updateUserSuccess, (state, {user}) => 
    userAdapter.updateOne({id:user.userId, changes: user}, state)),

    on(UserActions.deleteUserSuccess, (state, {deletedUserId}) =>
    userAdapter.removeOne(deletedUserId, state)),

)
export const getUserById = (userId: string) =>  (state: State) => state.entities[userId];