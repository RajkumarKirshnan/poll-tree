

import * as fromRoot from '@core/store/reducers/ui-reducer';
import * as fromUser from './user.reducer';
import {Action, combineReducers, createFeatureSelector, createSelector} from '@ngrx/store';

export const userFeatureKey = 'userFeatureKey';

export interface UserState{
    [fromUser.userServiceKey]: fromUser.State
}

export interface State extends fromRoot.State{
    [userFeatureKey]: UserState;
}

export function reducers(state: UserState | undefined, action:Action){
    return combineReducers({
        [fromUser.userServiceKey]: fromUser.reducer
    })(state, action)
}

export const getUserState = createFeatureSelector<UserState>(fromUser.userServiceKey);

export const getUsersEntitiesState = createSelector(
    getUserState,
    state => state[fromUser.userServiceKey]
)

export const { selectAll: getAllUsers} = fromUser.userAdapter.getSelectors(getUsersEntitiesState);

export const getUserById = (userId: string) => createSelector(
    getUsersEntitiesState, fromUser.getUserById(userId));