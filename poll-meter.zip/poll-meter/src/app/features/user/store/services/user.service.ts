import { Injectable } from '@angular/core';
import { Observable, pipe, of } from 'rxjs';
import { map, filter } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';
import { IUser } from '../../models';
import { environment } from '@app/env';

@Injectable({
    providedIn: 'root'
})

export class UserService {
    constructor(private http: HttpClient) { }

    public loadAllUsers(): Observable<IUser[]> {
        return this.http.get<IUser[]>(`${environment.oauthApi.baseUrl}/oauth/token`);
    }

    public loadUser(id: string): Observable<IUser> {
        return this.http.post<IUser>(`${environment.oauthApi.baseUrl}/oauth/token`, id);
    }

    public createUser(user: IUser): Observable<IUser>{
        return this.http.post<IUser>(`${environment.oauthApi.baseUrl}/oauth/token`, user);
    }

    public updateUser(user: IUser): Observable<IUser>{
        return this.http.post<IUser>(`${environment.oauthApi.baseUrl}/oauth/token`, user);
    }

    public searchUser(searchId: string): Observable<IUser[]>{
        return this.http.post<IUser[]>(`${environment.oauthApi.baseUrl}/oauth/token`, searchId);
    }

    public deleteUser(userId: string): Observable<string>{
        return this.http.delete<string>(`${environment.oauthApi.baseUrl}/oauth/token`);
    }
}