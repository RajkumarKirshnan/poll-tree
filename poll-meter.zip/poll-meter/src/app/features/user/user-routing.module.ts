import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { UserComponent } from './user.component';
import { AddUserPageComponent } from './containers/add-user-page/add-user-page.component';
import { ListUsersComponent } from './containers/list-users/list-users.component';
import { RouterPathConstants } from '@core/constants';

const routes: Routes = [
  {
    path: '',
    component: UserComponent,
    children: [
      {
        path: 'list-users',
        component: ListUsersComponent,
        data: {title: 'List Users'}
      },
      {
        path: 'add-user',
        component: AddUserPageComponent,
        data: {title: 'Add User'}
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class UserRoutingModule { }
