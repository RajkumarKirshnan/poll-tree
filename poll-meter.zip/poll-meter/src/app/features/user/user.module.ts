import { NgModule, CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import {StoreModule} from '@ngrx/store';
import {EffectsModule} from '@ngrx/effects';
import { AgGridModule } from 'ag-grid-angular';

import { UserRoutingModule} from './user-routing.module';
import { MaterialModule } from '@shared/components/material/material.module';
import { CoreComponentModule } from '@core/components/core-component.module';
import { CustomComponentModule } from '@shared/components/custom/custom-component.module';

import { UserComponent } from './user.component';
import { AddUserPageComponent } from '../user/containers/add-user-page/add-user-page.component';

//import { ContactsService } from '../contacts/services/contacts.service';
import {reducers, userFeatureKey} from './store/reducers';
import { UserEffects } from './store/effects';
import { ListUsersComponent } from './containers/list-users/list-users.component';
//import {ContactsStoreFacade} from '@app/contacts-store/facades/contacts.store-facade';
//import { SearchEffects } from './store/effects/search-effects';
//import 'ag-grid-enterprise';
import { ButtonRendererComponent } from '@shared/components/custom/renderer/button-renderer.component';

@NgModule({
  declarations: [
    UserComponent,
    AddUserPageComponent,
    ListUsersComponent,
    ButtonRendererComponent
  ],

  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    UserRoutingModule,
    MaterialModule,
    CoreComponentModule,
    CustomComponentModule,
    StoreModule.forFeature(userFeatureKey, reducers),
    EffectsModule.forFeature([UserEffects]),
    AgGridModule.withComponents([ButtonRendererComponent])
  ] ,
  schemas: [CUSTOM_ELEMENTS_SCHEMA, NO_ERRORS_SCHEMA] 
})
export class UserModule { }
