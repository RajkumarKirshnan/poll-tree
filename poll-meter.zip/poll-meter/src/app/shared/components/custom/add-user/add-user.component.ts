import { ChangeDetectionStrategy, Component, EventEmitter, OnChanges, OnInit, Output, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { IUserForm } from '@features/user/models';
import {FormBuilder, FormGroup, Validators, FormControl} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';

@Component({
  selector: 'pm-add-user',
  templateUrl: './add-user.component.html',
  styleUrls: ['./add-user.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AddUserComponent implements OnInit, OnChanges {

  form: FormGroup;
  toppings = new FormControl();
  stateList = [
    {
      key: "AN",
      name: "Andaman and Nicobar Islands"
    },
    {
      key: "AP",
      name: "Andhra Pradesh"
    },
    {
      key: "AR",
      name: "Arunachal Pradesh"
    },
    {
      key: "AS",
      name: "Assam"
    }
  ]

  public formTitle: string = '';

  @Output() save = new EventEmitter();

  constructor(private formBuilder: FormBuilder, public dialogRef: MatDialogRef<AddUserComponent>, @Inject(MAT_DIALOG_DATA) public data: any, private _snackBar: MatSnackBar) {
    this.formTitle = data.title;
    let formData = data.formData;
    this.form = this.formBuilder.group({
      basicInfo: this.formBuilder.group({
        firstName: new FormControl((formData.basicInfo && formData.basicInfo.firstName)||null , Validators.required),
        lastName: new FormControl((formData.basicInfo && formData.basicInfo.lastName)||null),
        middleName: new FormControl((formData.basicInfo && formData.basicInfo.middleName)||null),
        gender: new FormControl('Male'),
        email:  new FormControl((formData.basicInfo && formData.basicInfo.email)||null),
        contactNo:  new FormControl((formData.basicInfo && formData.basicInfo.contactNo)||null),
        isActive:  new FormControl(null),
        userTypeId:  new FormControl((formData.basicInfo && formData.basicInfo.userTypeId)||null),
        address: this.formBuilder.group({
          stateCode:  new FormControl((formData.basicInfo && formData.basicInfo.address.stateCode)||null),
          pinCode:  new FormControl((formData.basicInfo && formData.basicInfo.address.pinCode)||null),
          addressLine1:  new FormControl((formData.basicInfo && formData.basicInfo.address.addressLine1)||null),
          addressLine2:  new FormControl((formData.basicInfo && formData.basicInfo.address.addressLine2)||null)
        })
      }),
      subscriptionInfo: this.formBuilder.group({
        subsStartDate:  new FormControl(null),
        subsEndDate:  new FormControl(null)
      }),
      geography: this.formBuilder.group({
        states:  new FormControl([])
      }),
      /*modules: new FormControl([{Home:{
        "moduleId":1,
        "isActive":false
      },Dashboard:{"moduleId":1,
      "isActive":true}
    }]),*/
    modules:this.formBuilder.group({
      home: new FormControl(false),
      tab1: new FormControl(false),
      dashboard: new FormControl(false),
      tab2: new FormControl(false),
      settings: new FormControl(false),
      tab3: new FormControl(false),
      userManagement: new FormControl(false),
      tab4: new FormControl(false),
      customerManagement: new FormControl(false),
      tab5: new FormControl(false),
    }),
      logo: this.formBuilder.group({
        imageType: new FormControl('jpeg'),
        imageValue: new FormControl('<base 64 encoded string>')
      })      
    });
  }

  ngOnInit() {
    
  }

  ngOnChanges() {
  }

  public closeDialog(): void{
    this.dialogRef.close();
    //this.dialog.closeAll();
    
    this._snackBar.open("User Cancelled Successfully", "Cancelled", {
      duration: 2000, horizontalPosition: "right"
    });
  }

  public submit(): void {
    if (this.form.valid) {
      // this.save.emit(this.form.value);
    }
    // this.form.value.modules(toggle=>{
    //   console.log('calling : ',toggle);
    //   return toggle;
    // });
    
    this.form.value.modules = this.getSelectedPrivilages(this.form.value.modules);
      this.dialogRef.close(this.form.value);

    this._snackBar.open("User Added Successfully", "Added", {
      duration: 2000, horizontalPosition: "right"
    });    
  }

  private getSelectedPrivilages(privilageObj): any[]{
    type module = {"moduleId":number,"isActive":boolean }
    const privilages:module[] = Object.keys(privilageObj).map((i,index)=>{      
      return {moduleId:(-~index), isActive:privilageObj[i]}});
      return privilages.filter(privilage=>privilage.isActive);
  }
  
}
