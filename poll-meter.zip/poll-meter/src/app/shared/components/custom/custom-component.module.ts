import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule,ReactiveFormsModule } from '@angular/forms';

import { MaterialModule } from '@shared/components/material/material.module';
import { LoginComponent } from './login/login.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { ForgotPasswordComponent } from './forgot-password/forgot-password.component';
import { AddUserComponent } from './add-user/add-user.component';

const customComponent: any[] = [LoginComponent, ResetPasswordComponent, ForgotPasswordComponent, AddUserComponent];

@NgModule({
  declarations: [customComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    MaterialModule
  ],
  exports:[customComponent]
})
export class CustomComponentModule { }
