import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'pm-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ForgotPasswordComponent implements OnInit, OnChanges {

  formObject = {
    email: ''
  }

  form: FormGroup;

  @Output() save = new EventEmitter();

  constructor(public formBuilder: FormBuilder ) {
    this.form = this.formBuilder.group({
      email: [this.formObject.email, Validators.required]
    });
  }

  ngOnInit() {
  }

  ngOnChanges() {
    if (this.formObject) {
      this.form.patchValue({...this.formObject});
    }    
  }

  submit() {
    if (this.form.valid) {
      this.save.emit(this.form.value);
    }
  }

}
