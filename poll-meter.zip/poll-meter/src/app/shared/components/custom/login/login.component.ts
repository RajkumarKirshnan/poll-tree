import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'pm-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class LoginComponent implements OnInit, OnChanges {

  formObject = {
    username: '',
    password: ''
  }

  form: FormGroup;

  @Output() save = new EventEmitter();

  constructor(public formBuilder: FormBuilder ) {
    this.form = this.formBuilder.group({
      username: [this.formObject.username/*, Validators.required*/],
      password: [this.formObject.password/*, Validators.required*/]
    });
  }

  ngOnInit() {
  }

  ngOnChanges() {
    if (this.formObject) {
      this.form.patchValue({...this.formObject});
    }    
  }

  submit() {
    if (this.form.valid) {
      this.save.emit(this.form.value);
    }
  }

}
