// Author: T4professor

import { Component } from '@angular/core';
import { ICellRendererAngularComp } from 'ag-grid-angular';
// import { ICellRendererParams, IAfterGuiAttachedParams } from 'ag-grid-angular';
import {MatIconModule} from '@angular/material/icon'
@Component({
  selector: 'app-button-renderer',
  template: `
  <mat-icon (click)='formVisible($event)'>visibility</mat-icon>&nbsp;&nbsp;
  <mat-icon (click)='formEdit($event)'>edit</mat-icon>
    `
})

export class ButtonRendererComponent implements ICellRendererAngularComp {

  params;
  label: string;

  agInit(params): void {
    this.params = params;
    this.label = this.params.label || null;
  }

  refresh(params?: any): boolean {
    return true;
  }

  formVisible($event) {
    if (this.params.visibility instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.visibility(params);  
    }
  }

  formEdit($event) {
    if (this.params.edit instanceof Function) {
      // put anything into params u want pass into parents component
      const params = {
        event: $event,
        rowData: this.params.node.data
        // ...something
      }
      this.params.edit(params);  
    }
  }
}