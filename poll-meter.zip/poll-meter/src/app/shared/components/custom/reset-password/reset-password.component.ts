import {ChangeDetectionStrategy, Component, EventEmitter, Input, OnChanges, OnInit, Output} from '@angular/core';
import {FormBuilder, FormGroup, Validators} from '@angular/forms';

@Component({
  selector: 'pm-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ResetPasswordComponent implements OnInit {

  formObject = {
    oldPassword: '',
    newPassword: '',
    confirmPassword: ''
  }

  form: FormGroup;

  @Output() save = new EventEmitter();

  constructor( private formBuilder: FormBuilder ) { 
    this.form = this.formBuilder.group({
      oldPassword: [this.formObject.oldPassword, Validators.required],
      newPassword: [this.formObject.newPassword, Validators.required],
      confirmPassword: [this.formObject.confirmPassword, Validators.required]      
    });
  }

  ngOnInit() {

  }

  ngOnChanges() {
    if (this.formObject) {
      this.form.patchValue({...this.formObject});
    }    
  }

  submit() {
    if (this.form.valid) {
      this.save.emit(this.form.value);
    }
  }
}
