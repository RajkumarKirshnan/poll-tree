import { Component, OnInit } from '@angular/core';
import { DatagridService } from './dataGrid/datagrid.service';

@Component({
  selector: 'pm-userlist',
  templateUrl: './userlist.component.html',
  styleUrls: ['./userlist.component.scss']
})
export class UserlistComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
