export const environment = {
  production: false,
  appApi: {
    baseUrl: 'http://localhost:3000'
  },
  oauthApi: {
    baseUrl: 'http://52.15.174.45:9191'
  }
};
